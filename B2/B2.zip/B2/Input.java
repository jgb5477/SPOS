import java.util.Scanner;

public class Input{
    public static void main(String args[]){
        int a5 = 10;
        int temp = a5+5;
        /*Multi Line
        Comment*/
        System.out.println("Hello world");
        //Single Line Comment
    }
}